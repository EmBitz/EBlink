export EB_DEFAULT_PROBE=stlink
export EB_DEFAULT_SCRIPT=auto

